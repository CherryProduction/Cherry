from pyrogram import Client, filters
from plugins.settings.main_settings import module_list
from platform import python_version

from prefix import my_prefix
prefix = my_prefix()

@Client.on_message(filters.command('help', prefixes=prefix) & filters.me)
async def helps(client, message):
    await message.edit('Loading the menu. Please, wait...')
    me = await client.get_me() 
    owner_mention = f"<b>👤 | Owner — {me.mention}</b>"

    lists = []
    for k, v in module_list.items():
        lists.append(f'➣ {k}: {v}<br>')
    a = " "
    for i in lists:
        a = a.lstrip() + f'{i}'
    helpes = f"""
{len(module_list)} available modules.<br>
<br>
{a}
"""
    await message.delete()
    await client.send_video(
        chat_id=message.chat.id, 
        video='logo.mp4', 
        caption=f"""
<b>🍒 | CherryUserbot — Run </b>
{owner_mention}
<b>💻 | System — Linux</b>
<b>🔒 | Version: beta </b>
<b>🐍 | Python: {python_version()}</b>
<b>💼 | Modules: {len(module_list)}</b>

— Developed by Cherry Production. ⚡
""")

module_list['Help'] = f'{prefix}help'